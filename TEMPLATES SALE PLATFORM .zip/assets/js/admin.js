// Admin Interface
class AdminInterface {
    constructor() {
        this.isAuthenticated = false;
        this.adminData = null;
        this.templates = [];
        this.payments = [];
        this.failedPayments = [];
        this.stats = {};
        this.initialize();
    }
    
    async initialize() {
        await this.checkAuth();
        this.setupEventListeners();
        
        if (this.isAuthenticated) {
            await this.loadDashboardData();
        }
    }
    
    async checkAuth() {
        // Check if already logged in via session
        try {
            const response = await fetch(`${API_BASE}/auth.php?check=true`);
            const data = await response.json();
            
            if (data.success) {
                this.isAuthenticated = true;
                this.adminData = data.admin;
                this.showAdminInterface();
            } else {
                this.showLoginPage();
            }
        } catch (error) {
            console.error('Auth check failed:', error);
            this.showLoginPage();
        }
    }
    
    showLoginPage() {
        const loginPage = document.getElementById('login-page');
        const adminMain = document.getElementById('admin-main');
        
        if (loginPage) loginPage.style.display = 'flex';
        if (adminMain) adminMain.style.display = 'none';
    }
    
    showAdminInterface() {
        const loginPage = document.getElementById('login-page');
        const adminMain = document.getElementById('admin-main');
        
        if (loginPage) loginPage.style.display = 'none';
        if (adminMain) adminMain.style.display = 'block';
        
        // Update admin greeting
        const greeting = document.getElementById('admin-greeting');
        const usernameDisplay = document.getElementById('admin-username');
        
        if (greeting && this.adminData) {
            greeting.textContent = `Welcome, ${this.adminData.username}`;
        }
        if (usernameDisplay && this.adminData) {
            usernameDisplay.textContent = this.adminData.username;
        }
    }
    
    setupEventListeners() {
        // Login form
        const loginForm = document.getElementById('login-form');
        if (loginForm) {
            loginForm.addEventListener('submit', (e) => this.handleLogin(e));
        }
        
        // Logout button
        const logoutBtn = document.getElementById('logout-btn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', () => this.handleLogout());
        }
        
        // Navigation
        document.querySelectorAll('.admin-nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const section = link.dataset.section;
                this.showSection(section);
                
                // Update active link
                document.querySelectorAll('.admin-nav-link').forEach(l => {
                    l.classList.remove('active');
                });
                link.classList.add('active');
            });
        });
        
        // Refresh dashboard
        const refreshBtn = document.getElementById('refresh-dashboard');
        if (refreshBtn) {
            refreshBtn.addEventListener('click', () => this.loadDashboardData());
        }
        
        // Add template button
        const addTemplateBtn = document.getElementById('add-template-btn');
        if (addTemplateBtn) {
            addTemplateBtn.addEventListener('click', () => this.showTemplateForm());
        }
        
        // Cancel template form
        const cancelTemplateBtn = document.getElementById('cancel-template');
        if (cancelTemplateBtn) {
            cancelTemplateBtn.addEventListener('click', () => this.hideTemplateForm());
        }
        
        // Close form button
        const closeFormBtn = document.querySelector('.close-form-btn');
        if (closeFormBtn) {
            closeFormBtn.addEventListener('click', () => this.hideTemplateForm());
        }
        
        // Add template form submission
        const addTemplateForm = document.getElementById('add-template-form');
        if (addTemplateForm) {
            addTemplateForm.addEventListener('submit', (e) => this.handleAddTemplate(e));
        }
        
        // Change password form
        const changePasswordForm = document.getElementById('change-password-form');
        if (changePasswordForm) {
            changePasswordForm.addEventListener('submit', (e) => this.handleChangePassword(e));
        }
        
        // Save all settings
        const saveAllBtn = document.getElementById('save-all-settings');
        if (saveAllBtn) {
            saveAllBtn.addEventListener('click', () => this.saveAllSettings());
        }
        
        // Confirmation modal
        const cancelActionBtn = document.getElementById('cancel-action');
        const confirmActionBtn = document.getElementById('confirm-action');
        
        if (cancelActionBtn) {
            cancelActionBtn.addEventListener('click', () => {
                const modal = document.getElementById('confirmation-modal');
                if (modal) modal.style.display = 'none';
            });
        }
    }
    
    async handleLogin(e) {
        e.preventDefault();
        
        const form = e.target;
        const username = form.querySelector('#username').value;
        const password = form.querySelector('#password').value;
        const errorDiv = document.getElementById('login-error');
        
        if (errorDiv) errorDiv.style.display = 'none';
        
        try {
            const response = await fetch(`${API_BASE}/auth.php`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ username, password })
            });
            
            const data = await response.json();
            
            if (data.success) {
                this.isAuthenticated = true;
                this.adminData = { username: data.username };
                this.showAdminInterface();
                utils.showNotification('Login successful', 'success');
                
                // If first login with default credentials, show password change suggestion
                if (data.first_login) {
                    setTimeout(() => {
                        utils.showNotification('Please change your default password in Settings', 'warning', 10000);
                    }, 2000);
                }
            } else {
                if (errorDiv) {
                    const errorMessage = document.getElementById('error-message');
                    if (errorMessage) errorMessage.textContent = data.message;
                    errorDiv.style.display = 'block';
                }
                utils.showNotification(data.message || 'Login failed', 'error');
            }
        } catch (error) {
            console.error('Login error:', error);
            utils.showNotification('Network error. Please try again.', 'error');
        }
    }
    
    async handleLogout() {
        const confirmed = await utils.showConfirmation(
            'Confirm Logout',
            'Are you sure you want to log out?'
        );
        
        if (confirmed) {
            try {
                // Call logout endpoint if exists
                await fetch(`${API_BASE}/auth.php?action=logout`);
            } catch (error) {
                // Ignore logout errors
            }
            
            this.isAuthenticated = false;
            this.adminData = null;
            this.showLoginPage();
            utils.showNotification('Logged out successfully', 'success');
        }
    }
    
    showSection(sectionId) {
        // Hide all sections
        document.querySelectorAll('.admin-section').forEach(section => {
            section.classList.remove('active');
        });
        
        // Show selected section
        const targetSection = document.getElementById(sectionId);
        if (targetSection) {
            targetSection.classList.add('active');
            
            // Load section data
            switch (sectionId) {
                case 'dashboard':
                    this.loadDashboardData();
                    break;
                case 'templates':
                    this.loadTemplates();
                    break;
                case 'payments':
                    this.loadPayments();
                    break;
                case 'settings':
                    this.loadSettings();
                    break;
            }
        }
    }
    
    async loadDashboardData() {
        try {
            const response = await fetch(`${API_BASE}/payments.php?stats=true`);
            const data = await response.json();
            
            if (data.success) {
                this.stats = data.stats;
                this.payments = data.all_payments;
                this.failedPayments = data.failed_payments;
                
                this.updateDashboard();
            }
        } catch (error) {
            console.error('Error loading dashboard:', error);
            utils.showNotification('Failed to load dashboard data', 'error');
        }
    }
    
    updateDashboard() {
        // Update stats
        const totalTemplates = document.getElementById('total-templates');
        const totalSales = document.getElementById('total-sales');
        const successfulPayments = document.getElementById('successful-payments');
        const failedPayments = document.getElementById('failed-payments');
        
        if (totalTemplates) totalTemplates.textContent = this.templates.length;
        if (totalSales) totalSales.textContent = parseFloat(this.stats.total_sales || 0).toFixed(2);
        if (successfulPayments) successfulPayments.textContent = this.stats.successful_payments || 0;
        if (failedPayments) failedPayments.textContent = this.stats.failed_payments || 0;
        
        // Update recent transactions
        this.updateRecentTransactions();
    }
    
    updateRecentTransactions() {
        const container = document.getElementById('recent-transactions');
        if (!container) return;
        
        const recent = this.payments.slice(0, 5);
        
        container.innerHTML = recent.map(payment => `
            <tr>
                <td><code>${payment.transaction_id}</code></td>
                <td>KSh ${parseFloat(payment.amount).toFixed(2)}</td>
                <td>${payment.phone_number}</td>
                <td>
                    <span class="status-badge ${payment.status}">
                        ${payment.status}
                    </span>
                </td>
                <td>${utils.formatDate(payment.payment_date)}</td>
            </tr>
        `).join('');
    }
    
    async loadTemplates() {
        try {
            const response = await fetch(`${API_BASE}/templates.php`);
            const data = await response.json();
            
            if (data.success) {
                this.templates = data.data;
                this.renderTemplatesList();
            }
        } catch (error) {
            console.error('Error loading templates:', error);
            utils.showNotification('Failed to load templates', 'error');
        }
    }
    
    renderTemplatesList() {
        const container = document.getElementById('templates-list');
        if (!container) return;
        
        container.innerHTML = this.templates.map(template => `
            <tr>
                <td>${template.id}</td>
                <td>${utils.sanitize(template.name)}</td>
                <td>${utils.sanitize(template.description.substring(0, 60))}...</td>
                <td>KSh ${parseFloat(template.price).toFixed(2)}</td>
                <td>${template.downloads_count || 0}</td>
                <td>
                    <button class="btn btn-outline btn-sm delete-template-btn" data-id="${template.id}">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            </tr>
        `).join('');
        
        // Add delete event listeners
        document.querySelectorAll('.delete-template-btn').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                const templateId = e.target.closest('button').dataset.id;
                await this.deleteTemplate(templateId);
            });
        });
    }
    
    showTemplateForm() {
        const form = document.getElementById('template-form');
        if (form) {
            form.style.display = 'block';
            form.scrollIntoView({ behavior: 'smooth' });
        }
    }
    
    hideTemplateForm() {
        const form = document.getElementById('template-form');
        if (form) {
            form.style.display = 'none';
            form.reset();
        }
    }
    
    async handleAddTemplate(e) {
        e.preventDefault();
        
        const form = e.target;
        const name = form.querySelector('#template-name').value;
        const description = form.querySelector('#template-description').value;
        const price = form.querySelector('#template-price').value;
        const previewHtml = form.querySelector('#preview-html').value;
        
        // File inputs
        const backgroundFile = form.querySelector('#background-image').files[0];
        const templateFile = form.querySelector('#template-files').files[0];
        
        // Validation
        if (!name || !description || !price || !templateFile) {
            utils.showNotification('Please fill all required fields', 'warning');
            return;
        }
        
        if (!templateFile.name.endsWith('.zip')) {
            utils.showNotification('Template files must be in ZIP format', 'warning');
            return;
        }
        
        try {
            // Upload files
            let backgroundUrl = null;
            if (backgroundFile) {
                const bgFormData = new FormData();
                bgFormData.append('file', backgroundFile);
                
                const bgResponse = await fetch(`${API_BASE}/settings.php?action=upload`, {
                    method: 'POST',
                    body: bgFormData
                });
                const bgData = await bgResponse.json();
                
                if (bgData.success) {
                    backgroundUrl = bgData.file_url;
                }
            }
            
            // Upload template file
            const templateFormData = new FormData();
            templateFormData.append('file', templateFile);
            
            const templateResponse = await fetch(`${API_BASE}/settings.php?action=upload`, {
                method: 'POST',
                body: templateFormData
            });
            const templateData = await templateResponse.json();
            
            if (!templateData.success) {
                utils.showNotification('Failed to upload template file', 'error');
                return;
            }
            
            const templateUrl = templateData.file_url;
            
            // Save template to database
            const response = await fetch(`${API_BASE}/templates.php`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    name,
                    description,
                    price: parseFloat(price),
                    background_url: backgroundUrl,
                    zip_file_url: templateUrl,
                    preview_html: previewHtml
                })
            });
            
            const data = await response.json();
            
            if (data.success) {
                utils.showNotification('Template added successfully', 'success');
                this.hideTemplateForm();
                await this.loadTemplates();
                await this.loadDashboardData();
            } else {
                utils.showNotification(data.message || 'Failed to add template', 'error');
            }
        } catch (error) {
            console.error('Error adding template:', error);
            utils.showNotification('Failed to add template', 'error');
        }
    }
    
    async deleteTemplate(templateId) {
        const confirmed = await utils.showConfirmation(
            'Delete Template',
            'Are you sure you want to delete this template? This action cannot be undone.'
        );
        
        if (!confirmed) return;
        
        try {
            const response = await fetch(`${API_BASE}/templates.php`, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ id: templateId })
            });
            
            const data = await response.json();
            
            if (data.success) {
                utils.showNotification('Template deleted successfully', 'success');
                await this.loadTemplates();
                await this.loadDashboardData();
            } else {
                utils.showNotification(data.message || 'Failed to delete template', 'error');
            }
        } catch (error) {
            console.error('Error deleting template:', error);
            utils.showNotification('Failed to delete template', 'error');
        }
    }
    
    async loadPayments() {
        await this.loadDashboardData();
        this.renderPaymentsList();
        this.renderFailedPaymentsList();
    }
    
    renderPaymentsList() {
        const container = document.getElementById('payments-list');
        if (!container) return;
        
        container.innerHTML = this.payments.map(payment => `
            <tr>
                <td><code>${payment.transaction_id}</code></td>
                <td>
                    ${payment.full_name || 'Guest'}<br>
                    <small>${payment.email || ''}</small>
                </td>
                <td>${payment.phone_number}</td>
                <td>KSh ${parseFloat(payment.amount).toFixed(2)}</td>
                <td>
                    <span class="status-badge ${payment.status}">
                        ${payment.status}
                    </span>
                </td>
                <td>${utils.formatDate(payment.payment_date)}</td>
            </tr>
        `).join('');
    }
    
    renderFailedPaymentsList() {
        const container = document.getElementById('failed-payments-list');
        if (!container) return;
        
        container.innerHTML = this.failedPayments.map(payment => `
            <tr>
                <td><code>${payment.transaction_id}</code></td>
                <td>${payment.phone_number}</td>
                <td>KSh ${parseFloat(payment.amount).toFixed(2)}</td>
                <td>${payment.error_message}</td>
                <td>${utils.formatDate(payment.attempted_at)}</td>
            </tr>
        `).join('');
    }
    
    async loadSettings() {
        try {
            const settings = await utils.loadPlatformSettings();
            if (settings) {
                this.populateSettingsForm(settings);
            }
        } catch (error) {
            console.error('Error loading settings:', error);
        }
    }
    
    populateSettingsForm(settings) {
        // General settings
        const platformName = document.getElementById('platform-name');
        const contactPhone = document.getElementById('contact-phone');
        const contactEmail = document.getElementById('contact-email');
        
        if (platformName) platformName.value = settings.platform_name || '';
        if (contactPhone) contactPhone.value = settings.contact_phone || '';
        if (contactEmail) contactEmail.value = settings.contact_email || '';
        
        // Social settings
        const tiktokUrl = document.getElementById('tiktok-url');
        const facebookUrl = document.getElementById('facebook-url');
        
        if (tiktokUrl) tiktokUrl.value = settings.tiktok_url || '';
        if (facebookUrl) facebookUrl.value = settings.facebook_url || '';
    }
    
    async saveAllSettings() {
        try {
            // Get form values
            const platformName = document.getElementById('platform-name').value;
            const contactPhone = document.getElementById('contact-phone').value;
            const contactEmail = document.getElementById('contact-email').value;
            const tiktokUrl = document.getElementById('tiktok-url').value;
            const facebookUrl = document.getElementById('facebook-url').value;
            
            // Handle logo upload if selected
            const logoFile = document.getElementById('platform-logo').files[0];
            let logoUrl = null;
            
            if (logoFile) {
                const formData = new FormData();
                formData.append('file', logoFile);
                
                const uploadResponse = await fetch(`${API_BASE}/settings.php?action=upload`, {
                    method: 'POST',
                    body: formData
                });
                const uploadData = await uploadResponse.json();
                
                if (uploadData.success) {
                    logoUrl = uploadData.file_url;
                } else {
                    utils.showNotification('Failed to upload logo', 'error');
                    return;
                }
            }
            
            // Save settings
            const response = await fetch(`${API_BASE}/settings.php?action=update`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    platform_name: platformName,
                    logo_url: logoUrl,
                    contact_phone: contactPhone,
                    contact_email: contactEmail,
                    tiktok_url: tiktokUrl,
                    facebook_url: facebookUrl
                })
            });
            
            const data = await response.json();
            
            if (data.success) {
                utils.showNotification('Settings saved successfully', 'success');
                
                // Clear file input
                document.getElementById('platform-logo').value = '';
            } else {
                utils.showNotification(data.message || 'Failed to save settings', 'error');
            }
        } catch (error) {
            console.error('Error saving settings:', error);
            utils.showNotification('Failed to save settings', 'error');
        }
    }
    
    async handleChangePassword(e) {
        e.preventDefault();
        
        const form = e.target;
        const currentPassword = form.querySelector('#current-password').value;
        const newPassword = form.querySelector('#new-password').value;
        const confirmPassword = form.querySelector('#confirm-password').value;
        
        if (!currentPassword || !newPassword || !confirmPassword) {
            utils.showNotification('All fields are required', 'warning');
            return;
        }
        
        if (newPassword !== confirmPassword) {
            utils.showNotification('New passwords do not match', 'warning');
            return;
        }
        
        if (newPassword.length < 6) {
            utils.showNotification('Password must be at least 6 characters', 'warning');
            return;
        }
        
        try {
            const response = await fetch(`${API_BASE}/settings.php?action=change_password`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    current_password: currentPassword,
                    new_password: newPassword,
                    confirm_password: confirmPassword
                })
            });
            
            const data = await response.json();
            
            if (data.success) {
                utils.showNotification('Password changed successfully', 'success');
                form.reset();
            } else {
                utils.showNotification(data.message || 'Failed to change password', 'error');
            }
        } catch (error) {
            console.error('Error changing password:', error);
            utils.showNotification('Failed to change password', 'error');
        }
    }
}

// Initialize admin interface
document.addEventListener('DOMContentLoaded', () => {
    const adminInterface = new AdminInterface();
});