// User Interface
class UserInterface {
    constructor() {
        this.templates = [];
        this.selectedTemplates = [];
        this.cart = [];
        this.platformSettings = null;
        this.initialize();
    }
    
    async initialize() {
        await this.loadPlatformSettings();
        this.setupEventListeners();
        await this.loadTemplates();
        
        // Hide loading screen after content is loaded
        setTimeout(() => {
            const loadingScreen = document.getElementById('loading-screen');
            const userInterface = document.getElementById('user-interface');
            
            if (loadingScreen) {
                loadingScreen.style.opacity = '0';
                setTimeout(() => {
                    loadingScreen.style.display = 'none';
                    if (userInterface) userInterface.style.display = 'block';
                }, 500);
            } else if (userInterface) {
                userInterface.style.display = 'block';
            }
        }, 5000); // Maximum 5 seconds loading
    }
    
    async loadPlatformSettings() {
        this.platformSettings = await utils.loadPlatformSettings();
        if (this.platformSettings) {
            utils.updatePlatformUI(this.platformSettings);
        }
    }
    
    setupEventListeners() {
        // Admin login button
        const adminBtn = document.getElementById('admin-login-btn');
        if (adminBtn) {
            adminBtn.addEventListener('click', () => this.showAdminLogin());
        }
        
        // View templates button
        const viewBtn = document.getElementById('view-templates-btn');
        if (viewBtn) {
            viewBtn.addEventListener('click', () => {
                document.querySelector('#templates').scrollIntoView({ 
                    behavior: 'smooth' 
                });
            });
        }
        
        // Template search
        const searchInput = document.getElementById('template-search');
        if (searchInput) {
            searchInput.addEventListener('input', utils.debounce(() => {
                this.filterTemplates(searchInput.value);
            }, 300));
        }
        
        // Sort templates
        const sortSelect = document.getElementById('sort-templates');
        if (sortSelect) {
            sortSelect.addEventListener('change', () => {
                this.sortTemplates(sortSelect.value);
            });
        }
        
        // Preview selected
        const previewBtn = document.getElementById('preview-selected-btn');
        if (previewBtn) {
            previewBtn.addEventListener('click', () => this.previewSelectedTemplates());
        }
        
        // Purchase selected
        const purchaseBtn = document.getElementById('purchase-selected-btn');
        if (purchaseBtn) {
            purchaseBtn.addEventListener('click', () => this.showPaymentModal());
        }
        
        // Admin login form
        const adminForm = document.getElementById('admin-login-form');
        if (adminForm) {
            adminForm.addEventListener('submit', (e) => this.handleAdminLogin(e));
        }
        
        // Close preview button
        const closePreviewBtn = document.getElementById('close-preview-btn');
        if (closePreviewBtn) {
            closePreviewBtn.addEventListener('click', () => {
                const modal = document.getElementById('preview-modal');
                if (modal) modal.style.display = 'none';
            });
        }
        
        // Close success button
        const closeSuccessBtn = document.getElementById('close-success-btn');
        if (closeSuccessBtn) {
            closeSuccessBtn.addEventListener('click', () => {
                const modal = document.getElementById('success-modal');
                if (modal) modal.style.display = 'none';
            });
        }
    }
    
    async loadTemplates() {
        try {
            const response = await fetch(`${API_BASE}/templates.php`);
            const data = await response.json();
            
            if (data.success) {
                this.templates = data.data;
                this.renderTemplates();
            } else {
                utils.showNotification('Failed to load templates', 'error');
            }
        } catch (error) {
            console.error('Error loading templates:', error);
            utils.showNotification('Network error. Please check your connection.', 'error');
        }
    }
    
    renderTemplates() {
        const container = document.getElementById('templates-container');
        const noTemplates = document.getElementById('no-templates');
        
        if (!container) return;
        
        if (this.templates.length === 0) {
            container.innerHTML = '';
            if (noTemplates) noTemplates.style.display = 'block';
            return;
        }
        
        if (noTemplates) noTemplates.style.display = 'none';
        
        container.innerHTML = this.templates.map(template => `
            <div class="template-card" data-id="${template.id}">
                <div class="template-image" style="background: ${template.background_url || 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'}">
                    <div class="template-overlay">
                        <button class="btn btn-primary preview-single-btn" data-id="${template.id}">
                            <i class="fas fa-eye"></i> Preview
                        </button>
                    </div>
                </div>
                <div class="template-content">
                    <div class="template-header">
                        <h3 class="template-title">${utils.sanitize(template.name)}</h3>
                        <div class="template-price">KSh ${parseFloat(template.price).toFixed(2)}</div>
                    </div>
                    <p class="template-desc">${utils.sanitize(template.description)}</p>
                    <div class="template-footer">
                        <div class="checkbox-container">
                            <input type="checkbox" id="template-${template.id}" 
                                   ${this.isTemplateSelected(template.id) ? 'checked' : ''}>
                            <label for="template-${template.id}">Select</label>
                        </div>
                        <button class="btn btn-outline buy-single-btn" data-id="${template.id}">
                            <i class="fas fa-shopping-cart"></i> Buy Now
                        </button>
                    </div>
                </div>
            </div>
        `).join('');
        
        // Add event listeners
        this.attachTemplateEventListeners();
    }
    
    attachTemplateEventListeners() {
        // Checkbox selection
        document.querySelectorAll('.template-card input[type="checkbox"]').forEach(checkbox => {
            checkbox.addEventListener('change', (e) => {
                const templateId = parseInt(e.target.id.replace('template-', ''));
                this.toggleTemplateSelection(templateId, e.target.checked);
            });
        });
        
        // Preview buttons
        document.querySelectorAll('.preview-single-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const templateId = parseInt(e.target.closest('button').dataset.id);
                this.previewTemplate(templateId);
            });
        });
        
        // Buy now buttons
        document.querySelectorAll('.buy-single-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const templateId = parseInt(e.target.closest('button').dataset.id);
                this.buySingleTemplate(templateId);
            });
        });
    }
    
    isTemplateSelected(templateId) {
        return this.selectedTemplates.some(t => t.id === templateId);
    }
    
    toggleTemplateSelection(templateId, isSelected) {
        const template = this.templates.find(t => t.id === templateId);
        
        if (!template) return;
        
        if (isSelected) {
            if (!this.isTemplateSelected(templateId)) {
                this.selectedTemplates.push(template);
            }
        } else {
            this.selectedTemplates = this.selectedTemplates.filter(t => t.id !== templateId);
        }
        
        this.updateSelectionPanel();
    }
    
    updateSelectionPanel() {
        const panel = document.getElementById('selection-panel');
        const countElement = document.getElementById('selected-templates-count');
        const priceElement = document.getElementById('total-price');
        
        if (!panel || !countElement || !priceElement) return;
        
        const count = this.selectedTemplates.length;
        const totalPrice = this.selectedTemplates.reduce((sum, template) => 
            sum + parseFloat(template.price), 0
        );
        
        countElement.textContent = count;
        priceElement.textContent = totalPrice.toFixed(2);
        
        panel.style.display = count > 0 ? 'flex' : 'none';
    }
    
    previewTemplate(templateId) {
        const template = this.templates.find(t => t.id === templateId);
        if (!template) return;
        
        const modal = document.getElementById('preview-modal');
        const previewFrame = document.getElementById('preview-frame');
        
        if (modal && previewFrame) {
            // Create preview HTML
            const previewHTML = template.preview_html || this.createDefaultPreview(template);
            previewFrame.srcdoc = previewHTML;
            modal.style.display = 'flex';
        }
    }
    
    createDefaultPreview(template) {
        return `
            <!DOCTYPE html>
            <html>
            <head>
                <title>${template.name} - Preview</title>
                <style>
                    body {
                        font-family: 'Poppins', sans-serif;
                        margin: 0;
                        padding: 40px;
                        background: ${template.background_url || '#4361ee'};
                        color: white;
                        text-align: center;
                    }
                    .back-btn {
                        position: fixed;
                        top: 20px;
                        left: 20px;
                        background: white;
                        color: #333;
                        padding: 10px 20px;
                        border-radius: 5px;
                        text-decoration: none;
                        font-weight: bold;
                        border: none;
                        cursor: pointer;
                    }
                    h1 {
                        font-size: 48px;
                        margin: 60px 0 20px;
                    }
                    p {
                        font-size: 18px;
                        max-width: 600px;
                        margin: 0 auto 20px;
                    }
                </style>
            </head>
            <body>
                <button class="back-btn" onclick="window.close()">← Back to Templates</button>
                <h1>${template.name}</h1>
                <p>${template.description}</p>
                <p><strong>Price: KSh ${template.price}</strong></p>
                <p>This is a preview. Purchase to download the complete template files.</p>
            </body>
            </html>
        `;
    }
    
    previewSelectedTemplates() {
        if (this.selectedTemplates.length === 0) {
            utils.showNotification('Please select at least one template to preview', 'warning');
            return;
        }
        
        // Preview first selected template
        this.previewTemplate(this.selectedTemplates[0].id);
    }
    
    buySingleTemplate(templateId) {
        if (!this.isTemplateSelected(templateId)) {
            this.toggleTemplateSelection(templateId, true);
        }
        this.showPaymentModal();
    }
    
    showPaymentModal() {
        if (this.selectedTemplates.length === 0) {
            utils.showNotification('Please select at least one template to purchase', 'warning');
            return;
        }
        
        const modal = document.getElementById('mpesa-modal');
        const orderDetails = document.getElementById('order-details');
        const totalAmount = document.getElementById('mpesa-total');
        
        if (!modal || !orderDetails || !totalAmount) return;
        
        // Calculate total
        const total = this.selectedTemplates.reduce((sum, template) => 
            sum + parseFloat(template.price), 0
        );
        
        // Update order details
        orderDetails.innerHTML = this.selectedTemplates.map(template => `
            <div class="order-item">
                <span>${utils.sanitize(template.name)}</span>
                <span>KSh ${parseFloat(template.price).toFixed(2)}</span>
            </div>
        `).join('');
        
        totalAmount.textContent = total.toFixed(2);
        modal.style.display = 'flex';
        
        // Reset payment status
        const paymentStatus = document.getElementById('payment-status');
        if (paymentStatus) paymentStatus.style.display = 'none';
        
        // Reset form
        const form = document.getElementById('mpesa-payment-form');
        if (form) {
            form.reset();
            form.style.display = 'block';
        }
        
        // Remove existing event listeners and add new one
        const newForm = form.cloneNode(true);
        form.parentNode.replaceChild(newForm, form);
        newForm.addEventListener('submit', (e) => this.handlePayment(e));
    }
    
    async handlePayment(e) {
        e.preventDefault();
        
        const form = e.target;
        const name = form.querySelector('#customer-name').value;
        const email = form.querySelector('#customer-email').value;
        const phone = form.querySelector('#customer-phone').value;
        
        // Validation
        if (!name || !email || !phone) {
            utils.showNotification('Please fill in all required fields', 'warning');
            return;
        }
        
        if (!utils.validateEmail(email)) {
            utils.showNotification('Please enter a valid email address', 'warning');
            return;
        }
        
        if (!utils.validatePhone(phone)) {
            utils.showNotification('Please enter a valid 9-digit phone number', 'warning');
            return;
        }
        
        // Calculate total
        const total = this.selectedTemplates.reduce((sum, template) => 
            sum + parseFloat(template.price), 0
        );
        
        // Show payment status
        const paymentStatus = document.getElementById('payment-status');
        const formElement = document.getElementById('mpesa-payment-form');
        
        if (paymentStatus) paymentStatus.style.display = 'block';
        if (formElement) formElement.style.display = 'none';
        
        // Start countdown
        this.startPaymentCountdown();
        
        try {
            const response = await fetch(`${API_BASE}/payments.php`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    phone: phone,
                    amount: total,
                    template_ids: this.selectedTemplates.map(t => t.id),
                    customer_name: name,
                    customer_email: email
                })
            });
            
            const data = await response.json();
            
            if (data.success) {
                // Payment successful
                utils.showNotification('Payment successful!', 'success');
                
                // Show success modal
                this.showSuccessModal(data);
            } else {
                // Payment failed
                utils.showNotification(data.message || 'Payment failed', 'error');
                this.resetPaymentForm();
            }
        } catch (error) {
            console.error('Payment error:', error);
            utils.showNotification('Network error. Please try again.', 'error');
            this.resetPaymentForm();
        }
    }
    
    startPaymentCountdown() {
        let countdown = 60;
        const countdownElement = document.getElementById('payment-countdown');
        
        if (!countdownElement) return;
        
        const interval = setInterval(() => {
            countdown--;
            countdownElement.textContent = countdown;
            
            if (countdown <= 0) {
                clearInterval(interval);
                utils.showNotification('Payment timeout. Please try again.', 'warning');
                this.resetPaymentForm();
            }
        }, 1000);
    }
    
    resetPaymentForm() {
        const paymentStatus = document.getElementById('payment-status');
        const form = document.getElementById('mpesa-payment-form');
        
        if (paymentStatus) paymentStatus.style.display = 'none';
        if (form) form.style.display = 'block';
    }
    
    showSuccessModal(paymentData) {
        const modal = document.getElementById('success-modal');
        const transactionId = document.getElementById('success-transaction-id');
        const amount = document.getElementById('success-amount');
        const receipt = document.getElementById('success-receipt');
        const downloadLink = document.getElementById('download-link');
        
        if (!modal || !transactionId || !amount || !receipt || !downloadLink) return;
        
        // Close M-Pesa modal
        const mpesaModal = document.getElementById('mpesa-modal');
        if (mpesaModal) mpesaModal.style.display = 'none';
        
        // Update success modal
        transactionId.textContent = paymentData.transaction_id;
        amount.textContent = this.selectedTemplates.reduce((sum, t) => sum + parseFloat(t.price), 0).toFixed(2);
        receipt.textContent = paymentData.receipt || 'Pending';
        
        if (paymentData.download_url) {
            downloadLink.href = paymentData.download_url;
            downloadLink.style.display = 'inline-flex';
        } else {
            downloadLink.style.display = 'none';
        }
        
        modal.style.display = 'flex';
        
        // Clear selection
        this.selectedTemplates = [];
        this.updateSelectionPanel();
        
        // Uncheck all checkboxes
        document.querySelectorAll('.template-card input[type="checkbox"]').forEach(checkbox => {
            checkbox.checked = false;
        });
    }
    
    filterTemplates(searchTerm) {
        const filtered = this.templates.filter(template =>
            template.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            template.description.toLowerCase().includes(searchTerm.toLowerCase())
        );
        
        this.renderFilteredTemplates(filtered);
    }
    
    renderFilteredTemplates(filteredTemplates) {
        const container = document.getElementById('templates-container');
        const noTemplates = document.getElementById('no-templates');
        
        if (!container) return;
        
        if (filteredTemplates.length === 0) {
            container.innerHTML = '';
            if (noTemplates) noTemplates.style.display = 'block';
            return;
        }
        
        if (noTemplates) noTemplates.style.display = 'none';
        
        container.innerHTML = filteredTemplates.map(template => `
            <div class="template-card" data-id="${template.id}">
                <div class="template-image" style="background: ${template.background_url || 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'}">
                    <div class="template-overlay">
                        <button class="btn btn-primary preview-single-btn" data-id="${template.id}">
                            <i class="fas fa-eye"></i> Preview
                        </button>
                    </div>
                </div>
                <div class="template-content">
                    <div class="template-header">
                        <h3 class="template-title">${utils.sanitize(template.name)}</h3>
                        <div class="template-price">KSh ${parseFloat(template.price).toFixed(2)}</div>
                    </div>
                    <p class="template-desc">${utils.sanitize(template.description)}</p>
                    <div class="template-footer">
                        <div class="checkbox-container">
                            <input type="checkbox" id="template-${template.id}" 
                                   ${this.isTemplateSelected(template.id) ? 'checked' : ''}>
                            <label for="template-${template.id}">Select</label>
                        </div>
                        <button class="btn btn-outline buy-single-btn" data-id="${template.id}">
                            <i class="fas fa-shopping-cart"></i> Buy Now
                        </button>
                    </div>
                </div>
            </div>
        `).join('');
        
        this.attachTemplateEventListeners();
    }
    
    sortTemplates(sortBy) {
        let sorted = [...this.templates];
        
        switch (sortBy) {
            case 'price-low':
                sorted.sort((a, b) => a.price - b.price);
                break;
            case 'price-high':
                sorted.sort((a, b) => b.price - a.price);
                break;
            case 'newest':
                sorted.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
                break;
        }
        
        this.renderFilteredTemplates(sorted);
    }
    
    showAdminLogin() {
        const modal = document.getElementById('admin-login-modal');
        if (modal) {
            modal.style.display = 'flex';
        }
    }
    
    async handleAdminLogin(e) {
        e.preventDefault();
        
        const form = e.target;
        const username = form.querySelector('#login-username').value;
        const password = form.querySelector('#login-password').value;
        
        try {
            const response = await fetch(`${API_BASE}/auth.php`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ username, password })
            });
            
            const data = await response.json();
            
            if (data.success) {
                utils.showNotification('Login successful', 'success');
                
                // Close modal
                const modal = document.getElementById('admin-login-modal');
                if (modal) modal.style.display = 'none';
                
                // Redirect to admin page after 1 second
                setTimeout(() => {
                    window.location.href = 'admin.html';
                }, 1000);
            } else {
                utils.showNotification(data.message || 'Login failed', 'error');
            }
        } catch (error) {
            console.error('Login error:', error);
            utils.showNotification('Network error. Please try again.', 'error');
        }
    }
}

// Initialize user interface
document.addEventListener('DOMContentLoaded', () => {
    const userInterface = new UserInterface();
});